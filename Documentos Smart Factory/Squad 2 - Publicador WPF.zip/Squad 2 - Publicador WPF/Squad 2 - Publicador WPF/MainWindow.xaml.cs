﻿using MahApps.Metro.Controls;
using MQTTnet;
using MQTTnet.Client;
using MQTTnet.Protocol;
using System;
using System.IO.Ports;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Threading;

namespace Squad_2___Publicador_WPF
{
    public partial class MainWindow : MetroWindow
    {
        private IMqttClient _mqttClient;
        private SerialPort _serialPort;
        private string brokerUser = "admin";
        private string brokerPassword = "123";

        // --- Configurações MQTT ---
        private const string TopicUmidade = "smartfactory/umidade";
        private const string TopicLuminosidade = "smartfactory/luminosidade";
        private const string TopicTemperatura = "smartfactory/temperatura";
        private const string TopicInfravermelho = "smartfactory/infravermelho";
        private const string TopicUltrasonico = "smartfactory/ultrasonico";

        private DispatcherTimer _readingTimer;
        private bool _isReadingAutomatically = false;

        public MainWindow()
        {
            InitializeComponent();
            txtClientId.Text = Guid.NewGuid().ToString().Substring(0, 8);
            
            // Remove o botão de teste ou altera sua função
            btnteste.Content = "Iniciar Leitura Automática";
            
            // Inicializa o timer para leitura automática
            _readingTimer = new DispatcherTimer();
            _readingTimer.Interval = TimeSpan.FromMilliseconds(100); // Verifica a cada 100ms
            _readingTimer.Tick += ReadingTimer_Tick;
        }

        // --------------------------------------------------------------------------------
        // 1. CONEXÃO MQTT
        // --------------------------------------------------------------------------------

        private async void btnConnect_Click(object sender, RoutedEventArgs e)
        {
            if (_mqttClient != null && _mqttClient.IsConnected)
            {
                await DisconnectAsync();
                return;
            }

            var broker = txtBrokerAddress.Text;
            var port = int.Parse((cmbBrokerPort.SelectedItem as ComboBoxItem).Content.ToString());
            var clientId = txtClientId.Text;

            var factory = new MqttFactory();
            _mqttClient = factory.CreateMqttClient();

            var options = new MqttClientOptionsBuilder()
                .WithTcpServer(broker, port)
                .WithClientId(clientId)
                .WithCleanSession()
                .Build();

            try
            {
                btnConnect.IsEnabled = false;
                
                var result = await _mqttClient.ConnectAsync(options);

                if (result.ResultCode == MqttClientConnectResultCode.Success)
                {
                    UpdateStatus(true);
                    btnConnect.Content = "Desconectar";
                    
                    // Inicia automaticamente a leitura quando conectar
                    StartAutomaticReading();
                }
                else
                {
                    UpdateStatus(false, $"Falha: {result.ResultCode}");
                    btnConnect.Content = "Conectar";
                }
            }
            catch (Exception ex)
            {
                UpdateStatus(false, $"Erro: {ex.Message}");
                btnConnect.Content = "Conectar";
            }
            finally
            {
                btnConnect.IsEnabled = true;
            }
        }

        private async Task DisconnectAsync()
        {
            StopAutomaticReading();
            
            if (_mqttClient != null && _mqttClient.IsConnected)
            {
                await _mqttClient.DisconnectAsync();
            }

            if (_serialPort != null && _serialPort.IsOpen)
            {
                _serialPort.Close();
                _serialPort.Dispose();
                _serialPort = null;
            }

            UpdateStatus(false);
            btnConnect.Content = "Conectar";
        }

        // --------------------------------------------------------------------------------
        // 2. LEITURA AUTOMÁTICA
        // --------------------------------------------------------------------------------

        private void StartAutomaticReading()
        {
            try
            {
                if (_serialPort == null || !_serialPort.IsOpen)
                {
                    _serialPort = new SerialPort("COM9", 9600); 
                    _serialPort.NewLine = "\n";
                    _serialPort.Open();
                }

                _isReadingAutomatically = true;
                _readingTimer.Start();
                
                var successBrush = (SolidColorBrush)FindResource("StatusSuccessBrush");
                IndicatorSerial.Fill = successBrush;
                IndicatorData.Fill = successBrush;
                
                btnteste.Content = "Parar Leitura Automática";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Erro ao iniciar leitura automática: {ex.Message}", "Erro",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void StopAutomaticReading()
        {
            _isReadingAutomatically = false;
            _readingTimer.Stop();
            btnteste.Content = "Iniciar Leitura Automática";
        }

        private async void ReadingTimer_Tick(object sender, EventArgs e)
        {
            if (!_isReadingAutomatically || _serialPort == null || !_serialPort.IsOpen)
                return;

            try
            {
                if (_serialPort.BytesToRead > 0)
                {
                    string line = _serialPort.ReadLine().Trim();
                    
                    if (!string.IsNullOrEmpty(line))
                    {
                        await ProcessSensorData(line);
                    }
                }
            }
            catch (Exception ex)
            {
                // Log silencioso - não mostra messagebox para não interromper a aplicação
                Console.WriteLine($"Erro na leitura: {ex.Message}");
            }
        }

        private async Task ProcessSensorData(string data)
        {
            try
            {
                // Processa os dados no formato "SENSOR:VALOR"
                string[] parts = data.Split(':');
                if (parts.Length == 2)
                {
                    string sensorType = parts[0];
                    string value = parts[1];

                    // Atualiza a interface e publica no MQTT
                    switch (sensorType)
                    {
                        case "LDR":
                            ValueLuminosidade.Text = value;
                            await PublishMessageAsync(TopicLuminosidade, value);
                            break;
                            
                        case "CHUVA":
                            ValueUmidade.Text = value == "1" ? "Chovendo" : "Sem chuva";
                            await PublishMessageAsync(TopicUmidade, value);
                            break;
                            
                        case "ULTRASONICO":
                            ValueUltrassonico.Text = value;
                            await PublishMessageAsync(TopicUltrasonico, value);
                            break;
                            
                        case "INFRAVERMELHO":
                            ValueInfravermelho.Text = value == "1" ? "Porta Fechada" : "Porta Aberta";
                            await PublishMessageAsync(TopicInfravermelho, value);
                            break;
                            
                        case "TEMPERATURA":
                            ValueTemperatura.Text = value;
                            await PublishMessageAsync(TopicTemperatura, value);
                            break;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro ao processar dados: {ex.Message}");
            }
        }

        // Botão para iniciar/parar leitura manualmente
        private void Btnteste_OnClick(object sender, RoutedEventArgs e)
        {
            if (_isReadingAutomatically)
            {
                StopAutomaticReading();
            }
            else
            {
                if (_mqttClient == null || !_mqttClient.IsConnected)
                {
                    MessageBox.Show("Conecte-se ao broker MQTT primeiro.", "Aviso",
                        MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }
                StartAutomaticReading();
            }
        }

        /// <summary>
        /// Publica uma mensagem no broker Mosquitto.
        /// </summary>
        private async Task PublishMessageAsync(string topic, string payload)
        {
            if (!_mqttClient.IsConnected) return;

            try
            {
                var message = new MqttApplicationMessageBuilder()
                    .WithTopic(topic)
                    .WithPayload(payload)
                    .WithQualityOfServiceLevel(MqttQualityOfServiceLevel.AtLeastOnce) 
                    .WithRetainFlag(false)
                    .Build();

                await _mqttClient.PublishAsync(message, CancellationToken.None);
            }
            catch (Exception ex)
            {
                // Log silencioso para não interromper o fluxo
                Console.WriteLine($"Erro ao publicar: {ex.Message}");
            }
        }

        private void UpdateStatus(bool isConnected, string message = null)
        {
            var successBrush = (SolidColorBrush)FindResource("StatusSuccessBrush");
            var errorBrush = (SolidColorBrush)FindResource("StatusErrorBrush");
            var inactiveBrush = (SolidColorBrush)FindResource("StatusInactiveBrush");

            if (isConnected)
            {
                lblStatus.Text = "Conectado";
                lblStatus.Foreground = successBrush;
                IndicatorMqtt.Fill = successBrush;
            }
            else
            {
                lblStatus.Text = message ?? "Desconectado";
                lblStatus.Foreground = errorBrush;
                IndicatorMqtt.Fill = errorBrush;

                // Para a leitura automática se desconectar
                StopAutomaticReading();

                // Limpa os outros indicadores para inativo/erro
                IndicatorSerial.Fill = inactiveBrush;
                IndicatorData.Fill = inactiveBrush;
                
                // Limpa os valores dos sensores
                ValueUmidade.Text = ValueUltrassonico.Text = ValueInfravermelho.Text = 
                ValueTemperatura.Text = ValueLuminosidade.Text = "---";
            }
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            DisconnectAsync().Wait();
        }
    }
}