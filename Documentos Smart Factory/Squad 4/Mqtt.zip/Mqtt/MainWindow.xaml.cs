﻿using MQTTnet;
using MQTTnet.Client;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;

namespace Mqtt;

public partial class MainWindow : Window
{
    // Tópico MQTT fixo para inscrição
    private const string FixedTopic = "smartfactory/umidade";

    private IMqttClient? mqttClient;

    public MainWindow()
    {
        InitializeComponent();
        // Exibe o tópico fixo na interface
        LblFixedTopic.Text = $"Monitorando Tópico: {FixedTopic}";
        // Garante que o estado inicial da UI esteja correto
        UpdateUiState(false);
    }

    // --- Métodos de Conexão e Desconexão ---

    private async void BtnConnect_Click(object sender, RoutedEventArgs e)
    {
        if (string.IsNullOrWhiteSpace(TxtBrokerAddress.Text) ||
            string.IsNullOrWhiteSpace(TxtBrokerPort.Text))
        {
            MessageBox.Show("Por favor, preencha o endereço e a porta do broker.", "Erro de Validação", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (!int.TryParse(TxtBrokerPort.Text, out var port))
        {
            MessageBox.Show("A porta deve ser um número válida.", "Erro de Validação", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        // 1. Cria o cliente MQTT
        var factory = new MqttFactory();
        mqttClient = factory.CreateMqttClient();

        // 2. Define as opções de conexão
        var options = new MqttClientOptionsBuilder()
            .WithTcpServer(TxtBrokerAddress.Text, port)
            .WithClientId(Guid.NewGuid().ToString().Substring(0, 8)) 
            .WithCleanSession()
            .Build();

        // 3. Configura os Handlers de Evento
        SetupEventHandlers();

        try
        {
            UpdateStatus($"Conectando em {TxtBrokerAddress.Text}:{port}...");
            await mqttClient.ConnectAsync(options, CancellationToken.None);
        }
        catch (Exception ex)
        {
            UpdateStatus("Falha na conexão.", Colors.Red);
            MessageBox.Show($"Não foi possível conectar ao broker: {ex.Message}", "Erro de Conexão", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void SetupEventHandlers()
    {
        if (mqttClient == null) return;

        // Handler para conexão bem-sucedida
        mqttClient.ConnectedAsync += async e =>
        {
            await Dispatcher.InvokeAsync(async () =>
            {
                UpdateStatus("Conectado! Inscrito automaticamente no tópico...");
                UpdateUiState(true);

                // Se inscreve no tópico fixo
                await mqttClient.SubscribeAsync(FixedTopic);
                
                UpdateStatus($"Inscrito com sucesso e pronto para receber mensagens em: {FixedTopic}", Colors.Blue);
            });
        };

        // Handler para desconexão
        mqttClient.DisconnectedAsync += async e =>
        {
            await Dispatcher.InvokeAsync(() =>
            {
                UpdateStatus("Desconectado do Broker.", Colors.OrangeRed);
                LblReceivedMessage.Text = "Nenhuma mensagem recebida."; 
                UpdateUiState(false);
            });
        };

        // Handler para mensagem recebida
        mqttClient.ApplicationMessageReceivedAsync += async e =>
        {
            var topic = e.ApplicationMessage.Topic;
            var payload = Encoding.UTF8.GetString(e.ApplicationMessage.PayloadSegment);

            await Dispatcher.InvokeAsync(() =>
            {
                // Adiciona a nova mensagem à lista (ListBox)
                // O formato da mensagem será: [HH:mm:ss] [TOPICO]: MENSAGEM
                var time = DateTime.Now.ToString("HH:mm:ss");
                string messageEntry = $"[{time}] [{topic}]: {payload}";
                
                // Adiciona a nova mensagem ao topo da lista para visualização imediata
                ListBoxMessages.Items.Insert(0, messageEntry);

                // Atualiza a última mensagem recebida (apenas a payload para destaque)
                LblReceivedMessage.Text = payload;
                HighlightReceivedMessage();
            });
        };
    }

    private async void BtnDisconnect_Click(object sender, RoutedEventArgs e)
    {
        if (mqttClient is { IsConnected: true })
        {
            await mqttClient.DisconnectAsync();
        }
    }

    // --- Métodos de UI e Cleanup ---

    private void UpdateUiState(bool isConnected)
    {
        BtnConnect.IsEnabled = !isConnected;
        BtnDisconnect.IsEnabled = isConnected;

        TxtBrokerAddress.IsEnabled = !isConnected;
        TxtBrokerPort.IsEnabled = !isConnected;
    }
    
    // Método auxiliar para atualizar o status na UI com cor opcional
    private void UpdateStatus(string message, Color? color = null)
    {
        TxtStatus.Text = message;
        TxtStatus.Foreground = new SolidColorBrush(color ?? Colors.Black);
    }

    // Efeito visual rápido para nova mensagem
    private async void HighlightReceivedMessage()
    {
        var originalColor = LblReceivedMessage.Background;
        LblReceivedMessage.Background = new SolidColorBrush(Color.FromArgb(50, 0, 255, 0)); // Verde claro
        await Task.Delay(500); // Espera 500ms
        LblReceivedMessage.Background = originalColor;
    }

    private async void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
    {
        if (mqttClient is { IsConnected: true })
        {
            await mqttClient.DisconnectAsync();
        }
    }
}